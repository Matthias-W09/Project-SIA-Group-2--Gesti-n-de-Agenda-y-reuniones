package reuniones;

import java.io.IOException;
import controlador.Controller;
import vistas.VentanaMain;
import vistas.VentanaAgregarPersona;
import vistas.VentanaAgregaReunion;
import vistas.VentanaEliminar;
import vistas.VentanaMostrar;
import vistas.VentanaMostrarTipo;
import vistas.VentanaEditar;

public class Main {
    public static void main(String[] args) throws IOException {
       VentanaMain viewMain = new VentanaMain();
       VentanaAgregarPersona viewAP = new VentanaAgregarPersona();
       VentanaAgregaReunion viewAG = new VentanaAgregaReunion();
       VentanaEliminar viewEliminar = new VentanaEliminar();
       VentanaMostrar viewMostrar= new VentanaMostrar();
       VentanaMostrarTipo viewMT = new VentanaMostrarTipo();
       VentanaEditar viewEditar = new VentanaEditar();
       
       
       Controller controller = new Controller(viewMain, viewAP, viewAG, viewEliminar, viewMostrar, viewMT, viewEditar); 
       controller.inicializarDatos();       
    }
    
}
