package controlador;

//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
import modelo.Jefe;
import modelo.Persona;
import modelo.Reunion;
import modelo.Trabajador;
import vistas.VentanaMain;
import vistas.VentanaAgregarPersona;
import vistas.VentanaAgregaReunion;
import vistas.VentanaEliminar;
import vistas.VentanaMostrar;
import vistas.VentanaMostrarTipo;
import vistas.VentanaEditar;
//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

public class Controller implements MouseListener {
  List<Persona> personas;
  private VentanaMain viewMain;
  private VentanaAgregarPersona viewAP;
  private VentanaAgregaReunion viewAG;
  private VentanaEliminar viewEliminar;
  private VentanaMostrar viewMostrar;
  private VentanaMostrarTipo viewMT;
  private VentanaEditar viewEditar;

  // Constructor
  public Controller(VentanaMain viewMain, VentanaAgregarPersona viewAP, VentanaAgregaReunion viewAG,
      VentanaEliminar viewEliminar, VentanaMostrar viewMostrar, VentanaMostrarTipo viewMT, VentanaEditar viewEditar) {
    personas = new ArrayList<>();
    this.viewMain = viewMain;
    this.viewMain.getjButtonSalir().addMouseListener(this);
    this.viewMain.getMenuAgregarPersona().addMouseListener(this);
    this.viewMain.getMenuAgregarReunion().addMouseListener(this);
    this.viewMain.getMenuEliminar().addMouseListener(this);
    this.viewMain.getMenuMostrarReu().addMouseListener(this);
    this.viewMain.getMenuMostrarTipo().addMouseListener(this);
    this.viewMain.getMenuEditar().addMouseListener(this);
    this.viewAP = viewAP;
    this.viewAP.getjButtonAgregar().addMouseListener(this);
    this.viewAP.getjButtonSalir().addMouseListener(this);
    this.viewAG = viewAG;
    this.viewAG.getjButtonSalirAG().addMouseListener(this);
    this.viewAG.getjButtonAgregarReunion().addMouseListener(this);
    this.viewEliminar = viewEliminar;
    this.viewEliminar.getjBotonSalirEliminar().addMouseListener(this);
    this.viewEliminar.getBotonAceptarEliminarPersona().addMouseListener(this);
    this.viewEliminar.getBotonEliminarReunion().addMouseListener(this);
    this.viewMostrar = viewMostrar;
    this.viewMostrar.getjButtonSalirMostrar().addMouseListener(this);
    this.viewMostrar.getBotonMostrarReuniones().addMouseListener(this);
    this.viewMT = viewMT;
    this.viewMT.getjButtonAceptarMostrarTipo().addMouseListener(this);
    this.viewMT.getjButtonSalirMostrarTipo().addMouseListener(this);
    this.viewEditar = viewEditar;
    this.viewEditar.getjButtonEditarAceptar().addMouseListener(this);
    this.viewEditar.getjButtonEditarSalir().addMouseListener(this);
  }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // METODOS CONTROL MODELO
    public void inicializarDatos() throws FileNotFoundException, IOException {
    // Ruta del archivo de datos
      String rutaArchivo = "C:\\Users\\javie\\Desktop\\Reuniones\\src\\controlador\\datos.txt";  
    try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {  
      String linea;  
      int cantAgregado = -1; // Variable para contar la cantidad de personas agregadas  
      while ((linea = reader.readLine()) != null) {
        // Dividir la línea en campos usando coma como delimitador  
        String[] campos = linea.split(",");
        // Obtener datos de la persona    
        String nombre = campos[0].trim();  
        String correo = campos[1].trim();  
        String tipo = campos[2].trim();  
        String departamento = campos[3].trim();
        // Agregar la persona al modelo    
        agregarPersona(nombre, correo, tipo, departamento);  
        cantAgregado++;    

        // Verificar si hay más datos de reunión en la línea  
        if (campos.length > 4) {  
          for (int i = 4; i < campos.length; i++) {
            // Obtener datos de la reunió  
            String reunion = campos[i].trim();  
            i++;  
            String lugar = campos[i].trim();  
            i++;  
            int anio = Integer.parseInt(campos[i].trim());  
            i++;  
            int mes = Integer.parseInt(campos[i].trim());  
            i++;  
            int dia = Integer.parseInt(campos[i].trim());  
            i++;  
            int hora = Integer.parseInt(campos[i].trim());  
            i++;  
            int minuto = Integer.parseInt(campos[i].trim());
            // Crear objeto Reunion    
            Reunion reunion1 = new Reunion(reunion, lugar, LocalDate.of(anio, mes, dia), LocalTime.of(hora, minuto));    

            agregarReuniones(personas.get(cantAgregado), reunion1);    

          }  
        }  
      }
      } catch (IOException e) {
      // Manejar excepción en caso de error de lectura de archivo  
      JOptionPane.showMessageDialog(null, "Error en el archivo .txt");
      }
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\    

  public String cadenaPersona(Persona persona) {    
    String cadena;
    // Verificar el tipo de persona y construir la cadena correspondiente    
    if (persona instanceof Jefe) {    
      Jefe jefe = (Jefe) persona;    
      cadena = persona.getNombre() + "," + persona.getEmail() + ",Jefe," + jefe.getDepartamento();    
    }     else if (persona instanceof Trabajador) {    
      Trabajador tra = (Trabajador) persona;    
      cadena = persona.getNombre() + "," + persona.getEmail() + ",Trabajador," + tra.getCargo();    
    }     else {    
      cadena = persona.getNombre() + "," + persona.getEmail() + ",Otro";    
    }
    // Verificar si la persona tiene reuniones y agregar la información de las
    // reuniones a la cadena    
    if (persona.getReuniones() != null) {    
      for (Map.Entry<String, Reunion> entrada : persona.getReuniones().entrySet()) {    
        String clave = entrada.getKey();
        // Agregar información de la reunión a la cadena        
        Reunion reu = persona.getReuniones().get(clave);    
        LocalDate fecha = reu.getFecha();    
        LocalTime hora = reu.getHora();        

        cadena = cadena + "," + reu.getNombre() + "," + reu.getLugar() + "," + fecha.getYear() + ","
            + fecha.getMonthValue() + "," + fecha.getDayOfMonth() + "," + hora.getHour() + "," + hora.getMinute();    
      }    
    }    
    return cadena;
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

    public void exportarTxt() throws IOException {  
    // Ruta del archivo  
    String nombreArchivo = "C:\\Users\\javie\\Desktop\\Reuniones\\src\\controlador\\datos.txt";  
    BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo));
    // Iterar sobre todas las personas y escribir la cadena de cada una en el
    // archivo  
    for (int i = 0; i < personas.size(); i++) {  
      try {  
        String cadena = cadenaPersona(personas.get(i));  
        writer.write(cadena);  
        writer.newLine();      

      } catch (IOException e) {
        // Manejar excepción en caso de error de escritura en el archivo  
        JOptionPane.showMessageDialog(null, "Error en el archivo .txt");  
      }  
    }
      writer.close();
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

    public boolean agregarPersona(String nombre, String email, String tipo, String DepaCargo) {  
    // Verificar si la persona ya existe  
    if (!personas.isEmpty()) {  
      if (existePersona(nombre)) {  
        // Mostrar que ya existe por pantalla  
        return false;  
      }  
    }  
    // Crear la persona según el tipo  
    Persona nuevaPersona = crearPersona(nombre, email, tipo, DepaCargo);  
    // Agregar la persona a la lista  
    if (nuevaPersona != null) {  
      personas.add(nuevaPersona);  
      return true;  
    } else {  
      // Manejar un error si la creación de la persona falla  
      return false;  
    }
    }
  
    // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Método para verificar si existe una persona con el nombre especificado en la
  // lista de personas  
    public boolean existePersona(String nombre) {
    // Utiliza una expresión lambda para verificar si algún nombre de persona
    // coincide con el nombre especificado
      if (personas.stream().anyMatch(persona -> (persona.getNombre().equals(nombre)))) {  
      return true;
      }
    // Retorna false si no se encuentra ninguna persona con el nombre especificado
      return false;
    }
  
  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Método para buscar una persona por su nombre en la lista de personas  
    public Persona buscarPersona(String Nombre) {
    // Itera sobre la lista de personas para encontrar la persona con el nombre
    // especificado  
    for (int i = 0; i < personas.size(); i++) {  
      if (personas.get(i).getNombre().equals(Nombre))
        // Retorna la persona si se encuentra  
        return personas.get(i);  
    }
    // Retorna null si no se encuentra ninguna persona con el nombre especificado
      return null;
    }  

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Método para crear una persona según el tipo especificado  
    public Persona crearPersona(String nombre, String email, String tipo, String DepaCargo) {  
    // Dependiendo del tipo, creamos un trabajador o un jefe  
    switch (tipo) {  
      case "Trabajador":  
        return new Trabajador(nombre, email, DepaCargo);  
      case "Jefe":  
        return new Jefe(nombre, email, DepaCargo);  
      default:  
        // Manejar un tipo desconocido creando una persona genérica  
        return new Persona(nombre, email);  
    }
    }
  
    // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Método para crear una reunión con los datos especificados  
    public Reunion crearReunion(String nombreReu, String lugar, LocalDate fecha, LocalTime hora) {  
    Reunion reunion = new Reunion(nombreReu, lugar, fecha, hora);  
    return reunion;
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Método para agregar una reunión a una persona
    public final int agregarReuniones(Persona persona, Reunion newReunion) {
      for (int i = 0; i < personas.size(); i++) {
        if (personas.get(i).getNombre().equals(persona.getNombre())) {
          for (int j = 0; j < personas.get(i).getReuniones().size(); j++) {
            if (personas.get(i).getReuniones().get(newReunion.getNombre()) != null) {
              // Mostrar que ya existe por pantalla
              return 0;
            }
          }
          persona.getReuniones().put(newReunion.getNombre(), newReunion);
          // Caso que se agregue correctamente
          return 1;
        }
      }
      // Caso que no se agreguen las reuniones
      return 2;
    }
  
  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Método para mostrar la información de una persona en una ventana
    public void mostrarPersona(String nombrePersona) {
      // Recorre la lista de personas
      for (int i = 0; i < personas.size(); i++) {
        if (personas.get(i).getNombre().equals(nombrePersona)) {
          // Muestra los datos de la persona en una ventana
          JOptionPane.showMessageDialog(null,
            "Nombre: " + personas.get(i).getNombre() + "\nEmail: " + personas.get(i).getEmail());
          return;
        }
      }
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Metodo para eliminar una reunion
    public void eliminarReunion(String nombrePersona, String nombreReunion) {
      for (int i = 0; i < personas.size(); i++) {
      // Buscar si se encuentra la persona  
      if (personas.get(i).getNombre().equals(nombrePersona)) {
        // Buscar si se encuentra le reunion  
        personas.get(i).getReuniones().remove(nombreReunion);  
        return;  
      }
      }
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Metodo para eliminar una persona
    public void eliminarPersona(String nombrePersona) {
      for (int i = 0; i < personas.size(); i++) {
      // Buscar si se encuentra la persona  
      if (personas.get(i).getNombre().equals(nombrePersona)) {
        // Revisar si la persona tiene reuniones asignadas para eliminarlas  
        if (personas.get(i).getReuniones() != null) {
          // recorrer todas las reuniones de la persona  
          for (Map.Entry<String, Reunion> entrada : personas.get(i).getReuniones().entrySet()) {  
            String clave = entrada.getKey();    

            personas.get(i).getReuniones().remove(clave);  
          }  
        }  
        personas.remove(i);  
        return;  
      }
      }
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Funcion para editar una persona
  // SOBRECARGA DE METODOS CON PARAMETROS
    public void editarReunion(String nombrePersona, String nombreReunion, String nuevoNombreReunion, String lugar,
      LocalDate fecha, LocalTime hora) {  
    for (int i = 0; i < personas.size(); i++) {
      // Buscar si se encuentra la persona  
      if (personas.get(i).getNombre().equals(nombrePersona)) {  
        if (personas.get(i).getReuniones().get(nombreReunion) != null) {  
          personas.get(i).getReuniones().get(nombreReunion).setNombre(nuevoNombreReunion);  
          personas.get(i).getReuniones().get(nombreReunion).setLugar(lugar);  
          personas.get(i).getReuniones().get(nombreReunion).setFecha(fecha);  
          personas.get(i).getReuniones().get(nombreReunion).setHora(hora);  
          return;  
        }  
      }  
    }
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Funcion para editar una persona
  // Sobrecarga sin fecha ni hora
    public void editarReunion(String nombrePersona, String nombreReunion, String nuevoNombreReunion, String lugar) {  
    for (int i = 0; i < personas.size(); i++) {
      // Buscar si se encuentra la persona  
      if (personas.get(i).getNombre().equals(nombrePersona)) {  
        if (personas.get(i).getReuniones().get(nombreReunion) != null) {  
          personas.get(i).getReuniones().get(nombreReunion).setNombre(nuevoNombreReunion);  
          personas.get(i).getReuniones().get(nombreReunion).setLugar(lugar);  
          return;  
        }  
      }  
    }
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  // Funcion para editar una persona
    // sobrecarga solo fecha y hora
    public void editarReunion(String nombrePersona, String nombreReunion, LocalDate fecha, LocalTime hora) {  
    for (int i = 0; i < personas.size(); i++) {
      // Buscar si se encuentra la persona  
      if (personas.get(i).getNombre().equals(nombrePersona)) {  
        if (personas.get(i).getReuniones().get(nombreReunion) != null) {  
          personas.get(i).getReuniones().get(nombreReunion).setFecha(fecha);  
          personas.get(i).getReuniones().get(nombreReunion).setHora(hora);  
          return;  
        }  
      }  
    }
    }

  // -\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  // METODOS DE CONTROL VISTA
  // Metodo para pasar datos de la vista al metodo de agregar persona
    public void getViewInfoPersona() {  
    // Obtener datos.  
    String nombre = viewAP.getjTextNombre().getText();  
    String correo = viewAP.getjTextCorreo().getText();  
    String tipo = viewAP.getjTextTipo().getText();  
    String depaCargo = viewAP.getjTextDepaCargo().getText();    

    agregarPersona(nombre, correo, tipo, depaCargo);
    }

  // Metodo para pasar datos de la vista al metodo de agregar reunion  
    public void getViewInfoReunion() {
      // Obtener datos.
      String nombrePersonaReu = viewAG.getjTextNombrePersonaAG().getText();
      String nombreReu = viewAG.getjTextFieldNombreReunionAG().getText();
      String lugar = viewAG.getjTextFieldLugarReunionAG().getText();
      String fecha = viewAG.getjTextFieldFechaReunionAG().getText();
      String hora = viewAG.getjTextFieldHoraReunionAG().getText();
  
      // Convertir fecha y hora a objetos LocalDate y LocalTime
      LocalDate fechaReal = LocalDate.parse(fecha);
      LocalTime horaReal = LocalTime.parse(hora);
      // Crear objeto Reunion
      Reunion reunion = crearReunion(nombreReu, lugar, fechaReal, horaReal);
      Persona persona = buscarPersona(nombrePersonaReu);
      // Agregar reunion a la lista de reuniones de la persona
      agregarReuniones(persona, reunion);
    }
      

  // Metodo para pasar datos de la vista al metodo de eliminar persona  
  public void getViewInfoPersonaElinar() {  
    // Obtener datos.  
    String nombre = viewEliminar.getTextNombrePersonaEliminar().getText();    

    eliminarPersona(nombre);  
  }

  // Metodo para pasar datos de la vista al metodo de eliminar reunion    
  public void getViewInfoReunionElinar() {  
    // Obtener datos.  
    String nombre = viewEliminar.getTextNombrePersonaReunionEliminar().getText();  
    String reunion = viewEliminar.getTextNombreReunionEliminar().getText();    

    eliminarReunion(nombre, reunion);  
  }

  // Metodo para pasar datos de la vista al metodo de mostrar reunion
      public void searchByName() {
        viewMostrar.getTextEscribirReuniones().setText("");
        String nombre = viewMostrar.getTextReunionBuscar().getText();
        // Recorre el ArrayList de personas
        for (Persona persona : personas) {      
      // Si encuentra una persona con el nombre especificado      
      if (persona.getNombre().equals(nombre)) {      
        // Verifica si el mapa de reuniones de la persona está vacío      
        if (persona.getReuniones().isEmpty()) {      
          // Si no hay reuniones, muestra un mensaje indicando que no se encontraron
          // reuniones      
          viewMostrar.getTextEscribirReuniones().append("La persona '" + nombre + "' no tiene reuniones.\n\n");      
        } else {      
          // Si hay reuniones, muestra la información de cada reunión en el TextArea      
          persona.getReuniones().values().forEach(reunion -> {      
            viewMostrar.getTextEscribirReuniones().append("Nombre: " + reunion.getNombre() + "\n");      
            viewMostrar.getTextEscribirReuniones().append("Lugar: " + reunion.getLugar() + "\n");      
            viewMostrar.getTextEscribirReuniones().append("Fecha: " + reunion.getFecha() + "\n");      
            viewMostrar.getTextEscribirReuniones().append("Hora: " + reunion.getHora() + "\n\n");      
          });      
        }      
        // Termina el bucle una vez que se ha encontrado la persona      
        return;      
      }
        }
        // Si no se encuentra la persona con el nombre especificado
        viewMostrar.getTextEscribirReuniones().append("No se encontró ninguna persona con el nombre '" + nombre + "'.\n\n");
      }

    // Metodo para pasar datos de la vista al metodo de mostrar tipos de persona
      public void mostrarTipos() {
        viewMT.getjTextAreaMostrarTipo().setText("");
        String opcion = viewMT.getjTextFieldTipoMostrar().getText();
        int opcionR = Integer.parseInt(opcion);
        switch (opcionR) {    
      case 1:    
        for (int i = 0; i < personas.size(); i++) {    
          // ver si es instancia de jefe    
          if (personas.get(i).mostrarTipo().equals("Jefe")) {    
            // por cada vez del ciclo se muestra una nueva ventana    
            viewMT.getjTextAreaMostrarTipo()
                .append("Nombre: " + personas.get(i).getNombre() + "\nEmail: " + personas.get(i).getEmail());    
          }    
        }    
        break;    
      case 2:    
        for (int i = 0; i < personas.size(); i++) {    
          // ver si es instancia de trabajador    
          if (personas.get(i).mostrarTipo().equals("Trabajador")) {    
            viewMT.getjTextAreaMostrarTipo()
                .append("Nombre: " + personas.get(i).getNombre() + "\nEmail: " + personas.get(i).getEmail());    
          }    
        }    
        break;    
      case 3:    
        for (int i = 0; i < personas.size(); i++) {    
          // ver si no es instancia ni de trabajador ni de jefe    
          if (!(personas.get(i).mostrarTipo().equals("Trabajador"))
              && !(personas.get(i).mostrarTipo().equals("Jefe"))) {    
            viewMT.getjTextAreaMostrarTipo()
                .append("Nombre: " + personas.get(i).getNombre() + "\nEmail: " + personas.get(i).getEmail());    
          }    
        }    
        break;
        }
      }

  // Metodo para pasar datos de la vista al metodo de editar reunion
      public void getEditarReunion() {
        // Obtener datos de la vista para editar la reunión.
        String nombrePersona = viewEditar.getjTextFieldNombrePersonaEditar().getText();    
    String nombreReunion = viewEditar.getjTextFieldNombreReunionEditar().getText();    
    String nuevoNombreReunion = viewEditar.getjTextFieldNuevoNombreReunion().getText();    
    String lugar = viewEditar.getjTextFieldNuevoLugar().getText();
        String fecha = viewEditar.getjTextFieldNuevaFecha().getText();
        String hora = viewEditar.getjTextFieldNuevaHora().getText();
        
        if ("".equals(fecha) && "".equals(hora)) {    
      fecha = null;    
      hora = null;
        }
        if ("".equals(nuevoNombreReunion) && "".equals(lugar)) {    
      nuevoNombreReunion = null;    
      lugar = null;
        }
        // Transformar la fecha y hora ingresadas en objetos LocalDate y LocalTime.
        LocalDate fechaReal = LocalDate.parse(fecha);
        LocalTime horaReal = LocalTime.parse(hora);
    
        // Llamar al método correspondiente de edición de reunión.
        if (nuevoNombreReunion != null && lugar != null && fecha != null && hora != null) { // Sobrecarga con todos los parámetros   
      editarReunion(nombrePersona, nombreReunion, nuevoNombreReunion, lugar, fechaReal, horaReal);
        } else if (nuevoNombreReunion != null && lugar != null) { // Si solo se ingresan los campos de fecha y hora    
      editarReunion(nombrePersona, nombreReunion, nuevoNombreReunion, lugar);
        } else if (fecha != null && hora != null) { // Si solo se ingresan los campos de nombre y lugar    
      editarReunion(nombrePersona, nombreReunion, fecha, hora);
        }
      }
  
  // Control de eventos    
  @Override  
  public void mouseClicked(MouseEvent e) {  
    if (e.getSource() == viewMain.getjButtonSalir()) {    

      try {  
        exportarTxt();  
      } catch (IOException ex) {  
        Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);  
      }    

      System.exit(0);  
    }  
    if (e.getSource() == viewMain.getMenuAgregarPersona()) {  
      viewAP.setVisible(true);  
    }  
    if (e.getSource() == viewMain.getMenuAgregarReunion()) {  
      viewAG.setVisible(true);  
    }  
    if (e.getSource() == viewMain.getMenuEliminar()) {  
      viewEliminar.setVisible(true);  
    }  
    if (e.getSource() == viewMain.getMenuMostrarReu()) {  
      viewMostrar.setVisible(true);  
    }  
    if (e.getSource() == viewMain.getMenuMostrarTipo()) {  
      viewMT.setVisible(true);  
    }  
    if (e.getSource() == viewMain.getMenuEditar()) {  
      viewEditar.setVisible(true);  
    }  
    if (e.getSource() == viewAP.getjButtonAgregar()) {  
      getViewInfoPersona();    

      viewAP.getjTextNombre().setText("");  
      viewAP.getjTextCorreo().setText("");  
      viewAP.getjTextTipo().setText("");  
      viewAP.getjTextDepaCargo().setText("");  
    }  
    if (e.getSource() == viewAP.getjButtonSalir()) {  
      viewAP.setVisible(false);  
    }  
    if (e.getSource() == viewAG.getjButtonAgregarReunion()) {  
      getViewInfoReunion();    

      viewAG.getjTextFieldFechaReunionAG().setText("");  
      viewAG.getjTextFieldHoraReunionAG().setText("");  
      viewAG.getjTextFieldLugarReunionAG().setText("");  
      viewAG.getjTextFieldNombreReunionAG().setText("");  
      viewAG.getjTextNombrePersonaAG().setText("");  
    }  
    if (e.getSource() == viewAG.getjButtonSalirAG()) {  
      viewAG.setVisible(false);  
    }  
    if (e.getSource() == viewEliminar.getBotonAceptarEliminarPersona()) {  
      getViewInfoPersonaElinar();  
      viewEliminar.getTextNombrePersonaEliminar().setText("");  
    }  
    if (e.getSource() == viewEliminar.getBotonEliminarReunion()) {  
      getViewInfoPersonaElinar();  
      viewEliminar.getTextNombrePersonaReunionEliminar().setText("");  
      viewEliminar.getTextNombreReunionEliminar().setText("");  
    }  
    if (e.getSource() == viewEliminar.getjBotonSalirEliminar()) {  
      viewEliminar.setVisible(false);  
    }  
    if (e.getSource() == viewMostrar.getBotonMostrarReuniones()) {  
      searchByName();  
      viewMostrar.getTextReunionBuscar().setText("");  
    }  
    if (e.getSource() == viewMostrar.getjButtonSalirMostrar()) {  
      viewMostrar.setVisible(false);  
    }  
    if (e.getSource() == viewMT.getjButtonAceptarMostrarTipo()) {  
      mostrarTipos();  
      viewMT.getjTextFieldTipoMostrar().setText("");  
    }  
    if (e.getSource() == viewMT.getjButtonSalirMostrarTipo()) {  
      viewMT.setVisible(false);  
    }  
    if (e.getSource() == viewEditar.getjButtonEditarSalir()) {  
      viewEditar.setVisible(false);  
    }  
    if (e.getSource() == viewEditar.getjButtonEditarAceptar()) {  
      getEditarReunion();  
      viewEditar.getjTextFieldNombrePersonaEditar().setText("");
      ;  
      viewEditar.getjTextFieldNombreReunionEditar().setText("");  
      viewEditar.getjTextFieldNuevoNombreReunion().setText("");  
      viewEditar.getjTextFieldNuevoLugar().setText("");  
      viewEditar.getjTextFieldNuevaFecha().setText("");  
      viewEditar.getjTextFieldNuevaHora().setText("");  
    }  
  }    

  @Override  
  public void mousePressed(MouseEvent e) {  
  }    

  @Override  
  public void mouseReleased(MouseEvent e) {  
  }    

  @Override  
  public void mouseEntered(MouseEvent e) {  
  }    

  @Override  
  public void mouseExited(MouseEvent e) {  
  }
}