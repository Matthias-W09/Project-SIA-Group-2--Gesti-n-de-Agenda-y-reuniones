package controller;
//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate; 
import java.time.LocalTime; 
//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
import models.Jefe;
import models.Persona;
import models.Reunion;
import models.Trabajador;
import views.VentanaMain;
import views.VentanaAgregar;
import views.VentanaEliminar;
import views.VentanaMostrar;
//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

public class Controller implements ActionListener  {
    List<Persona> personas = new ArrayList<>();
    private VentanaMain viewMain;
    private VentanaAgregar viewAgregar;
    private VentanaEliminar viewEliminar;
    private VentanaMostrar viewMostrar;

  // Constructor
  public Controller(VentanaMain viewMain, VentanaAgregar viewAgregar, VentanaEliminar viewEliminar, VentanaMostrar viewMostrar) {
        this.viewMain = viewMain;
        this.viewAgregar = viewAgregar;
        this.viewEliminar = viewEliminar;
        this.viewMostrar = viewMostrar;

        //Agregar addMouseListener para cada botón, para poder obtener los eventos.
        this.viewAgregar.getBotonAceptarPersona().addActionListener(this);
        this.viewAgregar.getBotonAceptarReunion().addActionListener(this);
        this.viewEliminar.getBotonEliminarPersona().addActionListener(this);
        this.viewEliminar.getBotonEliminarReunion().addActionListener(this);
        this.viewMostrar.getBotonMostrarReuniones().addActionListener(this);

  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  public void inicializarDatos() throws FileNotFoundException, IOException {
    String rutaArchivo = ""; // Ruta del archivo CSV a leer

    try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
        String linea;
        int cantAgregado = -1;
        while ((linea = reader.readLine()) != null) {
            String[] campos = linea.split(",");

            String nombre = campos[0].trim();
            String correo = campos[1].trim();
            String tipo = campos[2].trim();
            String departamento= campos[3].trim();

            agregarPersona(nombre, correo, tipo, departamento);
            cantAgregado++;

            // Verificar si hay más datos de reunión
            if (campos.length > 4) {
              for (int i = 4; i < campos.length; i++) {
                  String reunion = campos[i].trim();
                  i++; // Avanzar al siguiente campo
                  String lugar = campos[i].trim();
                  i++; 
                  int anio = Integer.parseInt(campos[i].trim());
                  i++; 
                  int mes = Integer.parseInt(campos[i].trim());
                  i++; 
                  int dia = Integer.parseInt(campos[i].trim());
                  i++; 
                  int hora = Integer.parseInt(campos[i].trim());
                  i++; 
                  int minuto = Integer.parseInt(campos[i].trim());

                  Reunion reunion1 = new Reunion(reunion, lugar, LocalDate.of(anio,mes,dia), LocalTime.of(hora, minuto));

                  agregarReuniones(personas.get(cantAgregado),reunion1);

              }
              //Aqui ya estaria la persona con sus reuniones asignadas, falta ver si es necesario agregarlo a alguna parte
              //o ver si no se pierden los datos al ingresar otra persona
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
  public String cadenaPersona(Persona persona){
      String cadena;
      if(persona instanceof Jefe){
          Jefe jefe = (Jefe) persona;
          cadena = persona.getNombre()+","+persona.getEmail()+",Jefe,"+jefe.getDepartamento();
      }
      else{
          Trabajador tra = (Trabajador) persona;
          cadena = persona.getNombre()+","+persona.getEmail()+",Trabajador,"+tra.getCargo();
      }
      if(persona.getReuniones() != null){
          for (Map.Entry<String, Reunion> entrada : persona.getReuniones().entrySet()){
              String clave = entrada.getKey();

              Reunion reu = persona.getReuniones().get(clave);
              LocalDate fecha = reu.getFecha();
              LocalTime hora = reu.getHora();

              cadena = cadena+","+reu.getNombre()+","+reu.getLugar()+","+fecha.getYear()+","+fecha.getMonthValue()+","+fecha.getDayOfMonth()+","+hora.getHour()+","+hora.getMinute();
          } 
      }
      return cadena;
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
  public void exportarCSV(){
      //Direccion del archivo
      String nombreArchivo = "";

      for (int i = 0; i < personas.size(); i++){
          try {
              BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo));

              String cadena = cadenaPersona(personas.get(i));
              writer.write(cadena);
              writer.newLine();
              writer.close();

          } catch (IOException e) {

              e.printStackTrace();
          }
      }

  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
public boolean agregarPersona(String nombre, String email, String tipo, String DepaCargo) {
    // Verificar si la persona ya existe
    if (existePersona(nombre)) {
        // Mostrar que ya existe por pantalla
        return false;
    }
    // Crear la persona según el tipo
    Persona nuevaPersona = crearPersona(nombre, email, tipo, DepaCargo);
    // Agregar la persona a la lista
    if (nuevaPersona != null) {
        personas.add(nuevaPersona);
        return true;
    } else {
        // Manejar un error si la creación de la persona falla
        return false;
    }
}

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

private boolean existePersona(String nombre) {
  if (personas.stream().anyMatch(persona -> (persona.getNombre().equals(nombre)))) {
      return true;
  }
  return false;
}

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

private Persona crearPersona(String nombre, String email, String tipo, String DepaCargo) {
    // Dependiendo del tipo, creamos un trabajador o un jefe
    if (tipo.equals("Trabajador")) {
        return new Trabajador(nombre, email, DepaCargo);
    } else if (tipo.equals("Jefe")) {
        return new Jefe(nombre, email, DepaCargo);
    } else {
        // Manejar un tipo desconocido
        return null;
    }
}

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  public final int agregarReuniones(Persona persona,Reunion newReunion){
    for (int i = 0; i < personas.size(); i++) {
      if (personas.get(i).getNombre().equals(persona.getNombre())){
        for(int j = 0; j < personas.get(i).getReuniones().size(); j++){
          if(personas.get(i).getReuniones().get(newReunion.getNombre())!=null){
            //Mostrar que ya existe por pantalla
            return 0;
          }
        }
        persona.getReuniones().put(newReunion.getNombre(), newReunion);
        //Caso que se agregue correctamente
        return 1;
      }
    }
    //Caso que no se agreguen las reuniones
    return 2;
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
  public void mostrarReuniones(String nombrePersona){
    for (int i = 0; i < personas.size(); i++) {
        if (personas.get(i).getNombre().equals(nombrePersona)){
          //PONER DATOS DE LA PERSONA EN VENTANA
          return;
        }
      //PONER WEA EN dialogo DE QUE NO SE ENCONTRO LA PERSONA
      return;
    }
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  public void mostrarPersonas(){
    //PONER DATOS DE LAS PERSONAS EN VENTANA
    //CASO DE QUE NO EXISTAN PERSONAS
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  public void eliminarReunion(String nombrePersona, String nombreReunion){
    for (int i = 0; i < personas.size(); i++) {
        if(personas.get(i).getNombre().equals(nombrePersona)){
          personas.get(i).getReuniones().remove(nombreReunion);
          return;
        }
    }
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
  public void eliminarPersona(String nombrePersona){
    for (int i = 0; i < personas.size(); i++) {
        if(personas.get(i).getNombre().equals(nombrePersona)){
          //recorrer las reuniones de la persona y eliminar a la persona de listaAsistentes
          for(int j = 0; j < personas.get(i).getReuniones().size(); j++){
                eliminarReunion(nombrePersona,personas.get(i).getReuniones().get(j).getNombre());
            }
          }
          personas.remove(i);
          return;
        }
    }
    //PONER EN VENTANA DE QUE NO SE ENCONTRO LA PERSONA

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  //POSIBLE SOBRECARGA DE METODOS CON PARAMETROS
  public void editarReunion(String nombrePersona, String nombreReunion, String nuevoNombreReunion, String lugar, LocalDate fecha, LocalTime hora) {
      for (int i = 0; i < personas.size(); i++) {
          if (personas.get(i).getNombre().equals(nombrePersona)) {
              if (personas.get(i).getReuniones().get(nombreReunion) != null) {
                  personas.get(i).getReuniones().get(nombreReunion).setNombre(nuevoNombreReunion);
                  personas.get(i).getReuniones().get(nombreReunion).setLugar(lugar);
                  personas.get(i).getReuniones().get(nombreReunion).setFecha(fecha);
                  personas.get(i).getReuniones().get(nombreReunion).setHora(hora);
                  return;
              }
              // PONER EN VENTANA DE QUE NO SE ENCONTRO LA REUNION
          }
      }
    //PONER EN VENTANA DE QUE NO SE ENCONTRO LA PERSONA
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  //Sobrecarga sin fecha ni hora
    public void editarReunion(String nombrePersona, String nombreReunion, String nuevoNombreReunion, String lugar) {
      for (int i = 0; i < personas.size(); i++) {
          if (personas.get(i).getNombre().equals(nombrePersona)) {
              if (personas.get(i).getReuniones().get(nombreReunion) != null) {
                  personas.get(i).getReuniones().get(nombreReunion).setNombre(nuevoNombreReunion);
                  personas.get(i).getReuniones().get(nombreReunion).setLugar(lugar);
                  return;
              }
              // PONER EN VENTANA DE QUE NO SE ENCONTRO LA REUNION
          }
      }
    //PONER EN VENTANA DE QUE NO SE ENCONTRO LA PERSONA
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  //sobrecarga solo fecha y hora
  public void editarReunion(String nombrePersona, String nombreReunion, LocalDate fecha, LocalTime hora) {
      for (int i = 0; i < personas.size(); i++) {
          if (personas.get(i).getNombre().equals(nombrePersona)) {
              if (personas.get(i).getReuniones().get(nombreReunion) != null) {
                  personas.get(i).getReuniones().get(nombreReunion).setFecha(fecha);
                  personas.get(i).getReuniones().get(nombreReunion).setHora(hora);
                  return;
              }
              // PONER EN VENTANA DE QUE NO SE ENCONTRO LA REUNION
          }
      }
    //PONER EN VENTANA DE QUE NO SE ENCONTRO LA PERSONA
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  public void editarPersona(String nombrePersona, String nombre, String email){
    for (int i = 0; i < personas.size(); i++){
      if(personas.get(i).getNombre().equals(nombrePersona)){
        personas.get(i).setNombre(nombre);
        personas.get(i).setEmail(email);
        return;
      }
    }
    //PONER EN VENTANA DE QUE NO SE ENCONTRO LA PERSONA
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
  // Métodos para manejar la lista de personas asistentes de la clase reunion (DEBE EXISTIR LA PERSONA)
  /*
  public void agregarPersonaAsistente(String nombreReunion, String nombrePersona){
    for (int i = 0; i < personas.size(); i++){
      if(personas.get(i).getNombre().equals(nombrePersona)){
        personas.get(i).getReuniones().get(nombreReunion).getPersonasAsistentes.add(persona);
      }
  }
  //caso que no exita persona
}*/

//DEBE SER CON EL MAPA DE REUNIONES DEL PROGRAMA NO DE PERSONAS
 /* public void eliminarPersonaAsistente(Persona persona) {
      personasAsistentes.remove(persona);
  }*/

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\

  //funcion propia, mostrar el correo de las personas sin reuniones asignadas
  public void mostrarCorreosSinReuniones(){
    for (int i = 0; i < personas.size(); i++){
      if(personas.get(i).getReuniones().isEmpty()){
        //System.out.println(personas.get(i).getEmail());
      }
    }
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
    //Interaccion Con Vista Agregar
    public void getViewInfoPersona() {
        //Obtener datos.
        String nombre = viewAgregar.getTextNombrePersona().getText();
        String correo = viewAgregar.getTextCorreoPersona().getText();
        String tipo = viewAgregar.getTipoPersona();
        String depaCargo = viewAgregar.getDepaCargo().getText();

        agregarPersona(nombre, correo, tipo , depaCargo);
    }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  public void getViewInfoReunion() {
      //Obtener datos.
      String nombrePersonaReu = viewAgregar.getTextNombrePersonaReunion().getText();
      String nombreReu = viewAgregar.getTextNombreReunion().getText();
      String lugar = viewAgregar.getTextLugarReunion().getText();
      String fecha = viewAgregar.getTextFechaReunion().getText();
      String hora = viewAgregar.getTextHoraReunion().getText();  

      Persona persona = null;
      
      for(int i = 0 ; i < personas.size() ; i++){
        if(personas.get(i).getNombre().equals(nombrePersonaReu))
          persona = personas.get(i);
      }
    
      // Convertir fecha y hora a objetos LocalDate y LocalTime
      LocalDate fechaReal = LocalDate.parse(fecha);
      LocalTime horaReal = LocalTime.parse(hora);
      // Crear objeto Reunion
      Reunion reunion = new Reunion(nombreReu, lugar, fechaReal, horaReal);

      // Agregar reunion a la lista de reuniones de la persona
      agregarReuniones(persona, reunion);
  }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
    //Interaccion Con Vista Eliminar
    public void getViewInfoPersonaEliminar() {
        //Obtener datos.
        String nombre = viewEliminar.getTextNombrePersonaEliminar().getText();

        eliminarPersona(nombre);
    }

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
    public void getViewInfoReunionEliminar() {
        //Obtener datos.
        String nombre = viewEliminar.getTextNombrePersonaReunionEliminar().getText();
        String reunion = viewEliminar.getTextNombreReunionEliminar().getText();

        eliminarReunion(nombre,reunion);
    }
    
 public void searchByName() {
    String nombre = viewMostrar.getTextReunionBuscar().getText();
    // Recorre el ArrayList de personas
    for (Persona persona : personas) {
        // Si encuentra una persona con el nombre especificado
        if (persona.getNombre().equals(nombre)) {
            // Obtiene el mapa de reuniones de la persona
            persona.getReuniones().values().stream().map(reunion -> {
                // Muestra la información de cada reunión en el TextArea
                viewMostrar.getTextEscribirReuniones().append("Nombre: " + reunion.getNombre() + "\n");
                return reunion;
            }).map(reunion -> {
                viewMostrar.getTextEscribirReuniones().append("Lugar: " + reunion.getLugar() + "\n");
                return reunion;
            }).map(reunion -> {
                viewMostrar.getTextEscribirReuniones().append("Fecha: " + reunion.getFecha() + "\n");
                return reunion;
            }).forEachOrdered(reunion -> {
                viewMostrar.getTextEscribirReuniones().append("Hora: " + reunion.getHora() + "\n\n");
            });
            // Termina el bucle una vez que se ha encontrado la persona
            return;
        }
    }
    // Si no se encuentra la persona con el nombre especificado
    viewMostrar.getTextEscribirReuniones().append("No se encontró ninguna persona con el nombre '" + nombre + "'.\n");
}

  //-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\-//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\//-\\
  
     //Función para obtener los eventos de la vista. (REVISAR/PREGUNTAR SI SIRVE XDDD)
     @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == viewAgregar.getBotonAceptarPersona()) {
            getViewInfoPersona();
            viewAgregar.getTextNombrePersona().setText("");
            viewAgregar.getTextCorreoPersona().setText("");
            viewAgregar.getDepaCargo().setText("");
        } else if (e.getSource() == viewAgregar.getBotonAceptarReunion()) {
            getViewInfoReunion();
            viewAgregar.getTextNombrePersonaReunion().setText("");
            viewAgregar.getTextNombreReunion().setText("");
            viewAgregar.getTextLugarReunion().setText("");
            viewAgregar.getTextFechaReunion().setText("");
            viewAgregar.getTextHoraReunion().setText("");
        } else if (e.getSource() == viewMostrar.getBotonMostrarReuniones()) {
            searchByName();
            viewMostrar.getTextEscribirReuniones().setText("");
            viewMostrar.getTextReunionBuscar().setText("");
        } else if (e.getSource() == viewEliminar.getBotonEliminarPersona()) {
            getViewInfoPersonaEliminar();
            viewEliminar.getTextNombrePersonaEliminar().setText("");
        } else if (e.getSource() == viewEliminar.getBotonEliminarReunion()) {
            getViewInfoReunionEliminar();
            viewEliminar.getTextNombrePersonaReunionEliminar().setText("");
            viewEliminar.getTextNombreReunionEliminar().setText("");
        }
    }
}
